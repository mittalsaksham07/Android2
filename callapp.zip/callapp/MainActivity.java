package com.example.apoorva.callapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public final static String USERNAME="user";
    public final static String PASSWORD="pass";
    public void submit(View v)
    {
        EditText e1=(EditText)findViewById(R.id.editText);
        EditText e2=(EditText)findViewById(R.id.editText2);
        String s1=e1.getText().toString();
        String s2=e2.getText().toString();
        Intent i=new Intent(this,DisplayActivity.class);
        Bundle extras=new Bundle();
        extras.putString(USERNAME,s1);
        extras.putString(PASSWORD,s2);
        i.putExtras(extras);
        startActivity(i);
    }
}
