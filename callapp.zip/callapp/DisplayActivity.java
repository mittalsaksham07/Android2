package com.example.apoorva.callapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class DisplayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        TextView t1=(TextView)findViewById(R.id.textView);
        Bundle extras=getIntent().getExtras();
        String s1=extras.getString(MainActivity.USERNAME);
        String s2=extras.getString(MainActivity.PASSWORD);
        t1.setText("Username:"+s1+"\n"+"Password:"+s2);
    }
}
