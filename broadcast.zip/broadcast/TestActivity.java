package com.example.apoorva.broadcast;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class TestActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        TextView t=(TextView)findViewById(R.id.textView);
        Toast.makeText(this,"Sorry", Toast.LENGTH_LONG).show();
        t.setText("saksham");
    }
}
