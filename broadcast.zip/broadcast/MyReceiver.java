package com.example.apoorva.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;
public class MyReceiver extends BroadcastReceiver
{
    public void onReceive(Context c, Intent i)
    {
       i=new Intent(c,MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        //Toast.makeText(c, "Sorry", Toast.LENGTH_SHORT).show();
       c.startActivity(i);

    }
}
